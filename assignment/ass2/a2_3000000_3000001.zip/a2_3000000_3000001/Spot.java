/**
 * @author Mehrdad Sabetzadeh, University of Ottawa
 *
 */
public class Spot {
	private Car car;
	private int timestamp;

	public Car getCar() {

		// WRITE YOUR CODE HERE!

		return null; // Remove this statement when your implementation is complete.

	}

	public void setCar(Car car) {
	
		// WRITE YOUR CODE HERE!
	
	}

	public int getTimestamp() {
	
		// WRITE YOUR CODE HERE!
		
		return -1; // Remove this statement when your implementation is complete.

	}

	public void setTimestamp(int timestamp) {

		// WRITE YOUR CODE HERE!
		
	}

	public Spot(Car car, int timestamp) {

		// WRITE YOUR CODE HERE!
		
	}

	/**
	 * Returns a string representation of the spot
	 * This method is complete; you do not need to change it.
	 */
	public String toString() {
		return car + ", timestamp: " + timestamp;
	}
}

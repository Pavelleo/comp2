import java.util.Comparator;

public class BookComparator implements Comparator<Book> {

    // Implement the comparator method for books.

}
import java.util.ArrayList;

public class Library {

    private ArrayList<Book> library = new ArrayList<Book>();

    public Book getBook(int i) {
        return library.get(i);
    }

    public int getSize() {
        return library.size();
    }

    public void addBook(Book b) {
        // Your code here
    }

    public void sort() {
        // Your code here
    }

    public void printLibrary() {
        // Your code here
    }
}